package com.cafelist.controller;

import com.cafelist.model.CafeDao;
import com.cafelist.model.CafeDaoImpl;
import com.cafelist.model.UserDao;
import com.cafelist.model.UserDaoImpl;
import com.cafelist.vo.CafeVo;
import com.cafelist.vo.UserVo;

public class SelectController {
	private UserDao u_dao;
	private CafeDao c_dao;
	public SelectController() { //useBean을 사용하기 때문에 기본 생성자 사용
		this.u_dao = new UserDaoImpl();
		this.c_dao = new CafeDaoImpl();
	}
	
	public int login(String u_id, String u_pwd) {
		int result = -2;
		try {
			result = this.u_dao.login(u_id, u_pwd);
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		return result;
	}
	
	public boolean idcheck(String u_id) {
		boolean enabled = true;
		try {
			enabled = this.u_dao.idcheck(u_id);
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return enabled;
	}
	
	public UserVo readinfo(String u_id) {
		UserVo user = null;
		try {
			user = this.u_dao.selectUser_info(u_id);
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return user;
	}
	
	public CafeVo cafeintro(String u_id) {
		CafeVo cafe = null;
		try {
			cafe = this.c_dao.introCafe(u_id);
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return cafe;
	}
}
