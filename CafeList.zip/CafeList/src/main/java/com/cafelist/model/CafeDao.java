package com.cafelist.model;

import java.sql.SQLException;

import com.cafelist.vo.CafeVo;

public interface CafeDao {
	void insertCafe(CafeVo cafe, String u_id) throws SQLException; //카페 등록
	CafeVo introCafe(String c_name) throws SQLException;
}
