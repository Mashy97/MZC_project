package com.cafelist.model;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

import com.cafelist.vo.CafeVo;

public class CafeDaoImpl implements CafeDao {

	@Override
	public void insertCafe(CafeVo cafe, String u_id) throws SQLException {
		// 1, 2
		Connection conn = DBConnection.getConnection();

		// 3 Statement 객체 생성
		String sql = "{ call sp_cafe_insert(?,?,?,?,?,?,?,?,?,?) }";
		CallableStatement cstmt = conn.prepareCall(sql);
		cstmt.setString(1, cafe.setU_id(u_id));
		cstmt.setString(2, cafe.getC_name());
		cstmt.setString(3, cafe.getC_addr());
		cstmt.setString(4, cafe.getC_main());
		cstmt.setString(5, cafe.getC_menu1());
		cstmt.setString(6, cafe.getC_menu2());
		cstmt.setInt(7, cafe.getC_open());
		cstmt.setInt(8, cafe.getC_close());
		cstmt.setString(9, cafe.getC_contents());
		cstmt.setString(10, cafe.getC_hashtag());

		// 4 Statement 실행
		cstmt.executeUpdate();
		// 5
		if (cstmt != null)
			cstmt.close();
		if (conn != null)
			conn.close();
	}

	@Override
	public CafeVo introCafe(String u_id) throws SQLException {
		// 1, 2
		Connection conn = DBConnection.getConnection();

		// 3 Statement 객체 생성
		String sql = "{ call sp_cafe_intro(?,?,?,?,?,?,?,?,?,?) }";
		CallableStatement cstmt = conn.prepareCall(sql);
		cstmt.setString(1, u_id);
		cstmt.registerOutParameter(2, Types.VARCHAR);
		cstmt.registerOutParameter(3, Types.VARCHAR);
		cstmt.registerOutParameter(4, Types.VARCHAR);
		cstmt.registerOutParameter(5, Types.VARCHAR);
		cstmt.registerOutParameter(6, Types.VARCHAR);
		cstmt.registerOutParameter(7, Types.INTEGER);
		cstmt.registerOutParameter(8, Types.INTEGER);
		cstmt.registerOutParameter(9, Types.VARCHAR);
		cstmt.registerOutParameter(10, Types.VARCHAR);

		// 4
		cstmt.execute();

		// 5
		String c_name = cstmt.getString(2);
		String c_addr = cstmt.getString(3);
		String c_main = cstmt.getString(4);
		String c_menu1 = cstmt.getString(5);
		String c_menu2 = cstmt.getString(6);
		int c_open = cstmt.getInt(7);
		int c_close = cstmt.getInt(8);
		String c_contents = cstmt.getString(9);
		String c_hashtag = cstmt.getString(10);
		
		// 6
		if (cstmt != null)
			cstmt.close();
		if (conn != null)
			conn.close();
		
		CafeVo cafe = new CafeVo();
		cafe.setC_name(c_name);
		cafe.setC_addr(c_addr);
		cafe.setC_main(c_main);
		cafe.setC_menu1(c_menu1);
		cafe.setC_menu2(c_menu2);
		cafe.setC_open(c_open);
		cafe.setC_close(c_close);
		cafe.setC_contents(c_contents);
		cafe.setC_hashtag(c_hashtag);
		return cafe;
	}

}
