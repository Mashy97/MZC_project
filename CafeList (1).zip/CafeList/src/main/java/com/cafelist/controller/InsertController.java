package com.cafelist.controller;

import com.cafelist.model.CafeDao;
import com.cafelist.model.CafeDaoImpl;
import com.cafelist.model.UserDao;
import com.cafelist.model.UserDaoImpl;
import com.cafelist.vo.CafeVo;
import com.cafelist.vo.UserVo;

public class InsertController {
	private UserDao u_dao;
	private CafeDao c_dao;
	public InsertController() {
		this.u_dao = new UserDaoImpl();
		this.c_dao = new CafeDaoImpl();
	}
	
	public int insert(UserVo user) {
		try {
			u_dao.insertUser(user);
			return 1;
		}catch(Exception ex) {
			ex.printStackTrace();
			return 0;
		}
	}
	
	public int register(CafeVo cafe, String u_id) {
		try {
			c_dao.insertCafe(cafe, u_id);
			return 1;
		}catch(Exception ex) {
			ex.printStackTrace();
			return 0;
		}
	}
	
}
