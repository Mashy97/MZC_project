package com.cafelist.vo;

public class CafeVo {
	private String u_id, c_name, c_addr, c_main, c_menu1, c_menu2;
	private int c_open, c_close;
	private String c_contents, c_hashtag;
	
	public CafeVo() {}

	public CafeVo(String u_id, String c_name, String c_addr, String c_main, String c_menu1, String c_menu2, int c_open,
			int c_close, String c_contents, String c_hashtag) {
		this.u_id = u_id;
		this.c_name = c_name;
		this.c_addr = c_addr;
		this.c_main = c_main;
		this.c_menu1 = c_menu1;
		this.c_menu2 = c_menu2;
		this.c_open = c_open;
		this.c_close = c_close;
		this.c_contents = c_contents;
		this.c_hashtag = c_hashtag;
	}
	
	
	public String getU_id() {
		return u_id;
	}

	public String setU_id(String u_id) {
		this.u_id = u_id;
		return u_id;
	}

	public String getC_name() {
		return c_name;
	}

	public void setC_name(String c_name) {
		this.c_name = c_name;
	}

	public String getC_addr() {
		return c_addr;
	}

	public void setC_addr(String c_addr) {
		this.c_addr = c_addr;
	}

	public String getC_main() {
		return c_main;
	}

	public void setC_main(String c_main) {
		this.c_main = c_main;
	}

	public String getC_menu1() {
		return c_menu1;
	}

	public void setC_menu1(String c_menu1) {
		this.c_menu1 = c_menu1;
	}

	public String getC_menu2() {
		return c_menu2;
	}

	public void setC_menu2(String c_menu2) {
		this.c_menu2 = c_menu2;
	}

	public int getC_open() {
		return c_open;
	}

	public void setC_open(int c_open) {
		this.c_open = c_open;
	}

	public int getC_close() {
		return c_close;
	}

	public void setC_close(int c_close) {
		this.c_close = c_close;
	}

	public String getC_contents() {
		return c_contents;
	}

	public void setC_contents(String c_contents) {
		this.c_contents = c_contents;
	}

	public String getC_hashtag() {
		return c_hashtag;
	}

	public void setC_hashtag(String c_hashtag) {
		this.c_hashtag = c_hashtag;
	}
	
	
}
