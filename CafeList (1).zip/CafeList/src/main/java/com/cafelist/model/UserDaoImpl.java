package com.cafelist.model;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

import com.cafelist.vo.UserVo;

public class UserDaoImpl implements UserDao {

	@Override
	public boolean idcheck(String u_id) throws SQLException {
		//1,2
		Connection conn = DBConnection.getConnection();
				
		//3
		CallableStatement cstmt = conn.prepareCall("{ call sp_user_idcheck(?,?) }");
		cstmt.setString(1, u_id);
		cstmt.registerOutParameter(2, Types.VARCHAR);
		
		//4
		cstmt.execute(); // 반드시
				
		//5
		String ck_id = cstmt.getString(2); // 꺼내려하는것이 2번째꺼이기 때문에
		boolean enabled = true; // 초기값은 사용불가 값으로
		if(ck_id == null || ck_id.length() == 0) {
			enabled = false; //사용 가능
		}
				
		//6
		if(conn != null) conn.close();
		return enabled;
	}

	@Override
	public int login(String u_id, String u_pwd) throws SQLException {
		//1, 2
		Connection conn = DBConnection.getConnection();
		
		//3
		CallableStatement cstmt = conn.prepareCall("{ call sp_user_login(?,?)}" );
		cstmt.setString(1, u_id);
		cstmt.registerOutParameter(2, Types.VARCHAR);
		
		// 4
		cstmt.execute(); // 반드시 execute()를 할 것
		String db_pwd = cstmt.getString(2);
		int result = -2;
		if (db_pwd == null || db_pwd.trim().length() == 0) { // 그런 아이디가 없다면
			result = -1;
		} else if (!db_pwd.equals(u_pwd)) {// 계정은 맞는데 비밀번호 불일치
			result = 0;
		} else { // 계정, 비밀번호 둘 다 맞음
			result = 1;
		}
		
		//6
		if(cstmt != null) cstmt.close();
		if(conn != null) conn.close();
		
		return result;
	}

	@Override
	public void insertUser(UserVo user) throws SQLException {
		// 1, 2
		Connection conn = DBConnection.getConnection();

		// 3 Statement 객체 생성
		String sql = "{ call sp_user_insert(?,?,?,?,?,?) }";
		CallableStatement cstmt = conn.prepareCall(sql);
		cstmt.setString(1, user.getU_id());
		cstmt.setString(2, user.getU_pwd());
		cstmt.setString(3, user.getU_name());
		cstmt.setString(4, user.getU_email());
		cstmt.setString(5, user.getU_nickname());
		cstmt.setString(6, user.getU_type());

		// 4 Statement 실행
		cstmt.executeUpdate();
		// 5
		if (cstmt != null)
			cstmt.close();
		if (conn != null)
			conn.close();
	}

	@Override
	public UserVo selectUser_info(String u_id) throws SQLException {
		// 1,2
		Connection conn = DBConnection.getConnection();

		// 3
		CallableStatement cstmt = conn.prepareCall("{ call sp_user_bringinfo(?,?,?) }");
		cstmt.setString(1, u_id);
		cstmt.registerOutParameter(2, Types.VARCHAR);
		cstmt.registerOutParameter(3, Types.CHAR);

		// 4
		cstmt.execute();

		// 5
		String u_nickname = cstmt.getString(2);
		String u_type = cstmt.getString(3);
		// 6
		if (cstmt != null)
			cstmt.close();
		if (conn != null)
			conn.close();

		UserVo user = new UserVo();
		user.setU_nickname(u_nickname);
		user.setU_type(u_type);
		return user;
	}

}
