package com.cafelist.model;

import java.sql.SQLException;

import com.cafelist.vo.UserVo;

public interface UserDao {
	boolean idcheck(String u_id) throws SQLException; // 아이디 중복 체크
	int login(String u_id, String u_pwd) throws SQLException; // 로그인 0: 아이디 x 1: 아이디에 일치하는 비밀번호 x 2: 둘다 맞다
	void insertUser(UserVo user) throws SQLException; // 회원 가입
	UserVo selectUser_info(String u_id) throws SQLException; // id에 해당하는 닉네임 가져오기
	
}
