package com.cafelist.model;

import java.sql.Connection;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class DBConnection {
	public static Connection getConnection() {
		Connection conn = null;
		try{
			Context context = new InitialContext();
			Context env = (Context) context.lookup("java:comp/env");
			DataSource ds = (DataSource) env.lookup("jdbc/cafelist");
			conn = ds.getConnection();
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return conn;
	}
}
